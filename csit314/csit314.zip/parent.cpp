#include "parent.h"

parent::parent(int id,const std::string& name, const std::string& email, string password)
    : user(id,name, email, "Parent",password) {
}

int parent::menu() {
    
    int choice;
    while (true) {
        cout << "*********************" << endl;
        cout << "* 0. log out        *" << endl;
        cout << "* 1. view messages  *" << endl;
        cout << "* 2. send messages  *" << endl;
        cout << "* 3. check student  *" << endl;
        cout << "*********************" << endl;
        cout << "Enter an integer: ";
        if (!(cin >> choice)) {
            ClearScreen();
            cout << "Invalid input. Please enter a valid integer " << endl;;
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            menu();
        }
        switch (choice)
        {
        case 0:
            ClearScreen();
            return 0;
        case 1:
            ClearScreen();
            this->readMessages();
            Continue();
            break;
        case 2:
            ClearScreen();
            this->sendMessage();
            break;
        case 3:
            ClearScreen();
            this->checkStudent();
            break;
        default:
            ClearScreen();
            cout << "please enter a number between 0 and 3" << endl;
            break;
        }
        
    }


}
void parent::addStudent(student s) {
    listOfStudents.push_back(s);
}

void parent::printChildrens()
{
    for (int i = 0; i < listOfStudents.size(); i++)
    {
        cout << i + 1 << " " << listOfStudents[i].getName() << " " << listOfStudents[i].getID() << endl;
    }
}

void parent::checkStudent()
{
    int counter = 1;
    int choice;
    int status = false;
    std::cout << std::left  << std::setw(20) << "Student ID" << "Student Name" << std::endl;
    for (int i = 0; i < listOfStudents.size(); i++) {
        std::cout << std::setw(20) << listOfStudents[i].getID() << listOfStudents[i].getName() << std::endl;
    }
    cout << "enter your child ID" << endl;
    cin >> choice;

    for (int i = 0; i < listOfStudents.size(); i++) {
        if (choice == listOfStudents[i].getID()) {
            status = true;
            break;
        }
    }
    if (status == false) {
        ClearScreen();
        cout << "wrong ID" << endl;
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        checkStudent();
    }
    ClearScreen();
    cout << "the results of your child: " << endl;
    listOfStudents[choice-1].checkResults();
    cout << endl << endl;
    cout << "the messages that your child have: " << endl;
    listOfStudents[choice-1].readMessages();
    Continue();
}

