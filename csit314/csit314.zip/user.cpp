#include "user.h"
#include"database.h"

user::user(int id,const std::string& name, const std::string& email, const std::string& role, string password)
    : id(id),name(name), email(email), role(role),password(password) {
}

std::string user::getName() const {
    return name;
}

std::string user::getEmail() const {
    return email;
}

std::string user::getRole() const {
    return role;
}
std::string user::getPassword() const {
    return password;
}

int user::getID() const
{
    return id;
}
void user::Continue() {
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    string user_input;
    cout << "Please press anything to continue: ";
    getline(std::cin, user_input);
    system("cls");
}
void user::ClearScreen() {
    system("cls");
}
void user::readMessages() {
    ifstream inputFile("messages.txt");
    bool status = false;
    if (inputFile.is_open()) {
        string line;
        while (getline(inputFile, line)) {
            istringstream iss(line);
            string name;
            int id;
            string senderName;
            string senderID;
            string message;

            iss >> name >> id >> senderName >> senderID;
            getline(iss, message);
            if (id == this->id) {
                
                cout << "Name: " << name << std::endl;
                cout << "ID: " << id << std::endl;
                cout << "senderName: " << senderName << std::endl;
                cout << "senderID: " << senderID << std::endl;
                cout << "Message: " << message << std::endl;
                cout << "************************" << endl;
                status = true;
            }
        }
        inputFile.close();
    }
    else {
        cout << "Unable to open the file." << std::endl;
    }
    if (status == false) {
        cout << "you have no messages" << endl;
    }
}

int user::assignExam()
{
    cout << "this is the user class" << endl;
    return 0;
}

int user::menu()
{
    cout << "this is the user class" << endl;
    return 0;
}

void user::sendMessage() {
    
    
    cout << "who do you want to send your message to " << endl;
    cout << setw(5) << left << "ID" << setw(10) << "Name" << "Role" << endl; // Header row

    for (int i = 0; i < database::allusers.size(); i++)
    {
        cout << setw(5) << left << database::allusers[i].getID() << setw(10) << database::allusers[i].getName() << database::allusers[i].getRole() << endl;
    }


    cout << "enter the reciever id" << endl;
    int id;
    if (!(cin >> id)) {
        ClearScreen();
        cout << "Invalid input. Please enter a valid integer: " << endl;
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        sendMessage();
        
    }
    auto it = find_if(database::allusers.begin(), database::allusers.end(), [&](const user& user) {
        return user.getID() == id;
        });

    if (it != database::allusers.end()) {
        ClearScreen();
        cout << "User found! Name: " << it->getName() << endl;
        cout << "write your message " << endl;
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        string message;
        getline(cin, message);

        ofstream outputFile("messages.txt", std::ios::app);

        if (outputFile.is_open()) {
            string content = it->getName() + " " + std::to_string(it->getID()) + " " + this->name + " " + std::to_string(this->id) + " " + message;

            outputFile << content << endl;
            outputFile.close();  // Close the file
            ClearScreen();
            std::cout << "your message has been sent." << std::endl;
        }
        else {
            std::cout << "Unable to open the file." << std::endl;
        }
    }
    else {
        ClearScreen();
        cout << "User not found!" << endl;
    }
    
}
